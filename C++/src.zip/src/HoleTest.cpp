//
// Yinnon Sanders      23 November 2016
//

#include "Hole.h"
using namespace std;

int main()
{
	Hole hole1(true);
	hole1.print();
	Hole hole2(false);
	hole2.print();
}
